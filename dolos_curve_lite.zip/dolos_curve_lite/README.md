# DOLOS curve lite (72 review clips)

No WAV. No original clip names. No veracity labels.

- `index.csv`: anonymous sample list and coverage flags
- `clips/Sxx/clip.json`: AU04/07/12/14, log-RMS, F0, voicing, timestamps (clip-local seconds)
- `clips/Sxx/clip.json` also has IIU, information points, candidate events
- `clips/Sxx/curve.svg` and `curve.png`

IDs: S01–S72 samples, P01+ persons, U1+ IIUs, PT1+ points.
Candidate events are rule-based (au_change / rms_rise / pause), not deception or information points.
Time axis: OpenFace and audio at clip start = 0.
