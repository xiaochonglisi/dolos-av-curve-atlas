# DOLOS curve lite V2

No WAV. No veracity labels. No original clip names in this zip.

- series.json: AU04/07/12/14 + AU10/20/25/26, confidence, success, log-RMS, F0, voicing
- IIU bounds, information points, clipped word times, V1 events, separate articulatory events
- AU27 not present in OpenFace export (not fabricated)
- Do not mix V1 event counts with V2 articulatory event counts

V1 lite zip remains unchanged.
